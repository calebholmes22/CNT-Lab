CNT Zenodo Bundle
==================
Timestamp: 20251110-233206

This bundle collects:
- CALM_v1.1/  (Compact Alphabet of Latent Modes)
- MPC1_Gridworld/
- CNT_CriticalSuite/  (validation & finite-size scaling)

If any files/folders are missing, see manifest.json for copy status and confirm source paths.
