# How to cite

Holmes, C. (2025).
CNT Universal Drift Law v1.0 — Cross-Domain Time Series Panel.
Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

Replace `XXXXXXX` with the DOI assigned by Zenodo after publication.