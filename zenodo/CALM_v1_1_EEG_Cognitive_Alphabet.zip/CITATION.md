# How to cite

Holmes, C. (2025).
CALM v1.1: A 3-State EEG Cognitive Alphabet and Zoom Law.
Zenodo. https://doi.org/10.5281/zenodo.XXXXXXX

Replace `XXXXXXX` with the DOI that Zenodo assigns after publication.