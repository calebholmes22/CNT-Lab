# CNT Techno-Anomaly — Gold Verification

- RA=209.236537, Dec=-1.289745: old_votes=4, new_votes_at_source=nan, W1−W2=0.349, W2−W3=3.768, SIMBAD=✓  ()
- RA=210.910946, Dec=-1.291592: old_votes=4, new_votes_at_source=nan, W1−W2=-0.068, W2−W3=2.526, SIMBAD=—  ()
