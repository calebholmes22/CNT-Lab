# CNT Techno-Anomaly v2 — 20251016-200351

- Tiles: **9**
- Master stable: **12**
- Strict: **12**, Relaxed: **0**
- GOLD (pre-verify): **2**

- ID-locked GOLD (K≥4): **0**

## Key files
- `cnt_anomaly\out\stable_anomalies_master_20251016-200351.csv`
- `cnt_anomaly\out\stable_enriched_all_20251016-200351.csv`
- `cnt_anomaly\out\stable_enriched_strict_20251016-200351.csv`
- `cnt_anomaly\out\stable_enriched_relaxed_20251016-200351.csv`
- `cnt_anomaly\out\strict_gold_candidates_20251016-200351.csv`
- `cnt_anomaly\out\gold_verification_idlocked_20251016-200351.csv`
- `cnt_anomaly\out\web\index_20251016-200351.html`
- `cnt_anomaly\out\preregister_20251016-200351.json`
