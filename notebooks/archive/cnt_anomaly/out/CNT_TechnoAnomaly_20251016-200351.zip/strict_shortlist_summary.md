# CNT Techno-Anomaly — Strict Shortlist

Source file: `stable_enriched_strict_20251016-180208_grid3x3_K3.csv`

Diagnostics saved in: `cnt_anomaly\out\figures`

| rank | ra_deg | dec | votes | W1-W2 | W2-W3 | class_hint | cutouts |
|---:|---:|---:|---:|---:|---:|:---|:---:|
| 1 | 209.236537 | -1.289745 | 4 | 0.349 | 3.768 | ambiguous | yes |
| 2 | 210.910946 | -1.291592 | 4 | -0.068 | 2.526 | ambiguous | yes |
| 3 | 210.137533 | -2.022507 | 5 | 0.000 | 0.184 | ambiguous | yes |
| 4 | 210.997438 | -1.268082 | 5 | -0.032 | 0.244 | ambiguous | yes |
| 5 | 209.305983 | -0.421871 | 5 | -0.030 | -0.015 | ambiguous | yes |
| 6 | 209.917527 | -0.456956 | 5 | -0.086 | -0.060 | ambiguous | yes |
| 7 | 210.460969 | -2.001703 | 5 | -0.049 | 0.042 | ambiguous | yes |
| 8 | 211.229857 | -0.368180 | 3 | 0.148 | 3.682 | ambiguous | yes |
| 9 | 209.920252 | -0.434121 | 3 | 0.395 | 2.017 | ambiguous | yes |
| 10 | 208.941437 | -2.045680 | 4 | -0.044 | 0.820 | ambiguous | yes |
| 11 | 210.728039 | -0.496451 | 3 | 0.001 | 2.618 | ambiguous | yes |
| 12 | 210.305273 | -1.213642 | 4 | -0.082 | 0.411 | ambiguous | yes |
