# CNT Θ* Early-Warning — Results (frozen Θ* = 0.55)

**Registered (UTC):** 2025-10-18T04:09:49.361036Z
**Persistence:** k = 3
**Hazard target:** ~25% positives (bounds 15–35%)

## Top Segments (by AUC then Precision@Θ*)
                                               segment   N  W      AUC  Precision@Theta*  Lead@Hit(steps)  Lead@Any(steps)
                       cnt_cooling_log_20251015_121543  79 32 0.779503          0.353846             22.0             54.0
               cnt_cooling_log_20251015_121543_labeled  79 32 0.779503          0.353846             22.0             54.0
                   cnt_unified_cooling_20251015_133429 367 37 0.771948          0.633333             60.0            337.0
           cnt_unified_cooling_20251015_133429_labeled 367 37 0.771948          0.633333             60.0            337.0
   cnt_unified_cooling_20251015_133429_labeled_labeled 367 37 0.771948          0.633333             60.0            337.0
                   cnt_unified_cooling_20251015_132627 302 32 0.693024          0.512195             63.0            294.0
           cnt_unified_cooling_20251015_132627_labeled 302 32 0.693024          0.512195             63.0            294.0
                cnt_unified_cooling_v2_20251015_134310 319 32 0.261168          0.099237             25.0             25.0
        cnt_unified_cooling_v2_20251015_134310_labeled 319 32 0.261168          0.099237             25.0             25.0
cnt_unified_cooling_v2_20251015_134310_labeled_labeled 319 32 0.261168          0.099237             25.0             25.0

_Source CSV:_ `ewb_cooling_segments_20251017-235217.csv`
## Gauge Invariance Check (headline segments)

                                               segment  AUC_base  Precision_base  Lead@Hit_base  AUC_affine  Precision_affine  Lead@Hit_affine  AUC_decim  Precision_decim  Lead@Hit_decim                                                           sha256
                       cnt_cooling_log_20251015_121543  0.636432        0.500000            NaN    0.636432          0.500000              NaN   0.696667         0.352941            11.0 ee9da42acbd8aed7429ad596b7985d61301603eef00a1634eb0dba3498aec5b2
               cnt_cooling_log_20251015_121543_labeled  0.636432        0.500000            NaN    0.636432          0.500000              NaN   0.696667         0.352941            11.0 ee9da42acbd8aed7429ad596b7985d61301603eef00a1634eb0dba3498aec5b2
                   cnt_unified_cooling_20251015_133429  0.771948        0.633333           60.0    0.772140          0.633333             60.0   0.737873         0.435897            24.0 a1ae0a01537e27d0ed533ce37e04bd72ae09dbff5e2a584d68d26b91a485c056
           cnt_unified_cooling_20251015_133429_labeled  0.771948        0.633333           60.0    0.772140          0.633333             60.0   0.737873         0.435897            24.0 a1ae0a01537e27d0ed533ce37e04bd72ae09dbff5e2a584d68d26b91a485c056
   cnt_unified_cooling_20251015_133429_labeled_labeled  0.771948        0.633333           60.0    0.772140          0.633333             60.0   0.737873         0.435897            24.0 a1ae0a01537e27d0ed533ce37e04bd72ae09dbff5e2a584d68d26b91a485c056
                   cnt_unified_cooling_20251015_132627  0.694329        0.604167           71.0    0.709428          0.604167             71.0   0.782639         0.428571             5.0 1e1df04b94d531a850e7ae5c2c4c8283d7eac945e2574e01b6c8cba9a7916b19
           cnt_unified_cooling_20251015_132627_labeled  0.694329        0.604167           71.0    0.709428          0.604167             71.0   0.782639         0.428571             5.0 1e1df04b94d531a850e7ae5c2c4c8283d7eac945e2574e01b6c8cba9a7916b19
                cnt_unified_cooling_v2_20251015_134310  0.261168        0.099237           25.0    0.261168          0.099237             25.0   0.334371         0.077465             8.0 f6be857fe51ea968d59e66816c0884a6d932ae6951480e5db40402ed7015bb6e
        cnt_unified_cooling_v2_20251015_134310_labeled  0.261168        0.099237           25.0    0.261168          0.099237             25.0   0.334371         0.077465             8.0 f6be857fe51ea968d59e66816c0884a6d932ae6951480e5db40402ed7015bb6e
cnt_unified_cooling_v2_20251015_134310_labeled_labeled  0.261168        0.099237           25.0    0.261168          0.099237             25.0   0.334371         0.077465             8.0 f6be857fe51ea968d59e66816c0884a6d932ae6951480e5db40402ed7015bb6e
